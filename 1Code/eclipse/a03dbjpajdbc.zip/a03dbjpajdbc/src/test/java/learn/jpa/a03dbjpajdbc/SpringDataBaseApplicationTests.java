package learn.jpa.a03dbjpajdbc;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringDataBaseApplicationTests {

	@Test
	void contextLoads() {
	}

}
