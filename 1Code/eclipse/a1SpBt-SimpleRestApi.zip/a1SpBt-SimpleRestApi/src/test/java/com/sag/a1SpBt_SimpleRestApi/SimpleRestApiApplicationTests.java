package com.sag.a1SpBt_SimpleRestApi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SimpleRestApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
