package com.sag.Game;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GameSpFwApplication {

	public static void main(String[] args) {
		SpringApplication.run(GameSpFwApplication.class, args);
	}

}
