package com.sag.Game;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GameSpFwApplicationTests {

	@Test
	void contextLoads() {
	}

}
