package learn.maven.a02_maven;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class A02MavenApplication {

	public static void main(String[] args) {
		SpringApplication.run(A02MavenApplication.class, args);
	}

}
