package com.sag.a01spfwgame;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class A01spfwgameApplication {

	public static void main(String[] args) {
		SpringApplication.run(A01spfwgameApplication.class, args);
	}

}
