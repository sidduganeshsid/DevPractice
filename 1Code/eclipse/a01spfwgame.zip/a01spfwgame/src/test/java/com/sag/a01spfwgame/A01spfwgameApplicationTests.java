package com.sag.a01spfwgame;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class A01spfwgameApplicationTests {

	@Test
	void contextLoads() {
	}

}
